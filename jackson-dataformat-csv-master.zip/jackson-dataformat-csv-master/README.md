**NOTE**: This module has become part of
[Jackson Text Dataformats](../../../jackson-dataformats-text)
as of Jackson 2.9

This repo still exists to allow release of patch versions of older versions; it will be
hidden (made private) in near future.
