# Extension : Convert Fiddler sessions to JMeter .jmx Format

This framework is designed to be the extension of Fiddler to export in format of JMeter .jmx. Users are able to use this exported file in JMeter.

# Prerequisite

- Install Fiddler version 4.5.0.0 or latest
- Would be better to reduce administator issue, install Fiddler to C:/devsw

# Instruction to Setup

- Get into the /ExtensionFiddlertoJMeter/FiddlerConverterDll/bin/Debug 
- Copy `FiddlerConverterDll.dll` and `FiddlerConverterDll.pdb`
- Paste these files to C:\devsw\Fiddler\ImportExport 
- Reopen Fildder

