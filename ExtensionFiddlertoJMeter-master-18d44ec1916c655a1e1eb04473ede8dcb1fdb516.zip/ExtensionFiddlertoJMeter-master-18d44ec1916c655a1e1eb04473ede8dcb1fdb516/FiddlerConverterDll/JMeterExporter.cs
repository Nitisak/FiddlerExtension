﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fiddler;

[assembly: Fiddler.RequiredVersion("4.5.0.0")]

namespace FiddlerConverterDll
{

    [ProfferFormat("JMeter - With Tags and Listener", "Export .jmx Format with Tags of BP,UA,TR and Listener - Version 1.1.0\r\nThis extension framwork is supported Fiddler 4.5.0.0 or later\r\nAny Inquiries please contact : BPSPerformance@dstsystems.com")]
    [ProfferFormat("JMeter - Without Tags but Listener", "Export .jmx Format without Tags of BP,UA,TR but has Listener - Version 1.1.0\r\nThis extension framwork is supported Fiddler 4.5.0.0 or later\r\nAny Inquiries please contact : BPSPerformance@dstsystems.com")]
    [ProfferFormat("JMeter - With Tags but No Listener", "Export .jmx Format with Tags of BP,UA,TR but no Listener - Version 1.1.0\r\nThis extension framwork is supported Fiddler 4.5.0.0 or later\r\nAny Inquiries please contact : BPSPerformance@dstsystems.com")]
    [ProfferFormat("JMeter - Without Tags and Listener", "Export .jmx Format without Tags of BP,UA,TR and Listener - Version 1.1.0\r\nThis extension framwork is supported Fiddler 4.5.0.0 or later\r\nAny Inquiries please contact : BPSPerformance@dstsystems.com")]

    public class JMeterExporter : ISessionExporter
    {
        public bool ExportSessions(string sFormat, Session[] oSessions, Dictionary<string, object> dictOptions,
                                    EventHandler<ProgressCallbackEventArgs> evtProgressNotifications)
        {
            bool bResult = true;
            string sFilename = null, sTmpName = null;

            // [3] Ask the Fiddler GUI to obtain the filename to export to
            sFilename = Fiddler.Utilities.ObtainSaveFilename("Export As " + sFormat, "JMeter Files (*.jmx)|*.jmx");
            sTmpName = Path.GetFileNameWithoutExtension(sFilename);

            if (String.IsNullOrEmpty(sFilename)) return false;

            if (!Path.HasExtension(sFilename)) sFilename = sFilename + ".jmx";


            ProfferType type = ProfferType.Type1;
            if (sFormat.Equals("JMeter - With Tags and Listener"))
            {
                type = ProfferType.Type1;
            }
            else if(sFormat.Equals("JMeter - Without Tags but Listener"))
            {
                type = ProfferType.Type2;
            }
            else if (sFormat.Equals("JMeter - With Tags but No Listener"))
            {
                type = ProfferType.Type3;
            }
            else if (sFormat.Equals("JMeter - Without Tags and Listener"))
            {
                type = ProfferType.Type4;
            }

            try
            {

                Encoding encUTF8NoBOM = new UTF8Encoding(false);
                // [4]
                
                JMeterTestPlan jMeterTestPlan = new JMeterTestPlan(oSessions, sTmpName, type);
                System.IO.StreamWriter sw = new StreamWriter(sFilename, false, encUTF8NoBOM);

                // [5]
                sw.Write(jMeterTestPlan.Jmx);
                sw.Close();

                Fiddler.FiddlerApplication.Log.LogString("Successfully exported sessions to JMeter Test Plan");
                Fiddler.FiddlerApplication.Log.LogString(String.Format("\t{0}", sFilename));
            }
            catch (Exception eX)
            {
                Fiddler.FiddlerApplication.Log.LogString(eX.Message);
                Fiddler.FiddlerApplication.Log.LogString(eX.StackTrace);
                bResult = false;
            }
            return bResult;
        }

        public void Dispose()
        {
        }
    }

}
