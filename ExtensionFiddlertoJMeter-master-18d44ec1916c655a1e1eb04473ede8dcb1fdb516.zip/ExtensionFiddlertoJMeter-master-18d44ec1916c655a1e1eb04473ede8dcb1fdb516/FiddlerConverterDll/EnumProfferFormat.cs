﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiddlerConverterDll
{

    public enum ProfferType
    {
        Type1,  //JMeter - With Tags and Listener
        Type2,  //JMeter - Without Tags but Listener 
        Type3,  //JMeter - With Tags but No Listener
        Type4   //JMeter - Without Tags and Listener
    }

    
}
