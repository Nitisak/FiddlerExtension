﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Fiddler;
using System.Xml.Linq;


namespace FiddlerConverterDll
{
    /// <summary>
    /// A simple representation of a basic JMeterTestPlan
    /// </summary>
    public class JMeterTestPlan
    {
        // [1]
        private SessionList sessionList;
        private Fiddler.Session[] sessions; 
        private string OfileName;
        public JMeterTestPlan()
        {
            sessions = new Fiddler.Session[0];
            sessionList = new SessionList(sessions, null, ProfferType.Type1);
        }

        public JMeterTestPlan(Fiddler.Session[] oSessions, string outputFilename, ProfferType type)
        {
            this.sessions = oSessions;
            this.OfileName = outputFilename;
            sessionList = new SessionList(oSessions, outputFilename, type);
        }

        // [2] Return the final formatted JMX string
        public string Jmx
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");

                XDocument doc = XDocument.Parse(this.Xml);
                sb.Append(doc.ToString());

                return sb.ToString();
            }
        }

        private string Xml
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("<jmeterTestPlan version=\"1.2\" properties=\"2.3\">");
                // [4]
                sb.Append("<hashTree>");
                sb.Append(String.Format("<TestPlan guiclass=\"TestPlanGui\" testclass=\"TestPlan\" testname=\"{0}\" enabled=\"true\">", this.OfileName));
                sb.Append("<stringProp name=\"TestPlan.comments\">Export Sessions from Fiddler.</stringProp>");
                sb.Append("<boolProp name=\"TestPlan.functional_mode\">false</boolProp>");
                sb.Append("<boolProp name=\"TestPlan.serialize_threadgroups\">false</boolProp>");
                sb.Append("<elementProp name=\"TestPlan.user_defined_variables\" elementType=\"Arguments\" guiclass=\"ArgumentsPanel\" testclass=\"Arguments\" testname=\"User Defined Variables\" enabled=\"true\">");
                sb.Append("<collectionProp name=\"Arguments.arguments\"/>");
                sb.Append("</elementProp>");
                sb.Append("<stringProp name=\"TestPlan.user_define_classpath\"></stringProp>");
                sb.Append("</TestPlan>");
                sb.Append(sessionList.Xml);

                sb.Append("</hashTree>");
                sb.Append("</jmeterTestPlan>");
                return sb.ToString();
            }
        }
    }

    /// <summary>
    ///  [5] This class represents a list of HTTP Sampler nodes
    /// </summary>
    public class SessionList
    {
        private Fiddler.Session[] sessions;
        private ProfferType Type;
        private string OfileName;
        public SessionList()
        {
            sessions = new Fiddler.Session[0];
        }

        public SessionList(Fiddler.Session[] oSessions, string outputFilename, ProfferType type)
        {
            this.OfileName = outputFilename;
            this.sessions = oSessions;
            this.Type = type;
        }

        public List<Session> getSessions(Session[] list, string color)
        {
            List<Session> lst = new List<Session>();

            
            foreach (Session x in list)
            {
                if (color.Equals(string.Empty))
                {
                    if (!x.oFlags.ContainsKey("ui-color"))
                    {
                        lst.Add(x);
                    }
                }
                else
                {
                    if (x.oFlags.ContainsKey("ui-color"))
                    {
                        if (x.oFlags["ui-color"].Equals(color))
                        {
                            lst.Add(x);
                        }
                    }
                }
                
            }

            return lst;
        }


        // Return the HTTP Sampler nodes
        public string Xml
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                bool ch = false;

                List<Session> init = getSessions(sessions, "Green");
                List<Session> end = getSessions(sessions, "Red");
                List<Session> action = getSessions(sessions, string.Empty);

                if (init.Count > 0 || action.Count > 0 || end.Count > 0)
                {
                    sb.Append("<hashTree>");

                    if (init.Count > 0)
                    {
                        sb.Append("<SetupThreadGroup guiclass=\"SetupThreadGroupGui\" testclass=\"SetupThreadGroup\" testname=\"Init_ThreadGroup\" enabled=\"true\">");
                        sb.Append("<stringProp name=\"ThreadGroup.on_sample_error\">continue</stringProp>");
                        sb.Append("<elementProp name=\"ThreadGroup.main_controller\" elementType=\"LoopController\" guiclass=\"LoopControlPanel\" testclass=\"LoopController\" testname=\"Loop Controller\" enabled=\"true\">");
                        sb.Append("<boolProp name=\"LoopController.continue_forever\">false</boolProp>");
                        sb.Append("<stringProp name=\"LoopController.loops\">1</stringProp>");
                        sb.Append("</elementProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.num_threads\">1</stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.ramp_time\">1</stringProp>");

                        sb.Append("<boolProp name=\"ThreadGroup.scheduler\">false</boolProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.duration\"></stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.delay\"></stringProp>");
                        sb.Append("</SetupThreadGroup>");

                        sb.Append("<hashTree>");

                        int runNum = 0, subrun = 0;
                        string nameBefore = string.Empty, nameAfter = string.Empty;
                        bool[] chList = new bool[init.Count];

                        for (int h = 0; h < init.Count; h++)
                        {
                            chList[h] = false;
                        }

                        for (int j = 0; j < init.Count; j++)
                        {
                            subrun = 0;
                            ch = false;
                            if (!chList[j])
                            {
                                for (int i = j; i < init.Count; i++)
                                {
                                    if (!chList[i])
                                    {
                                        if (init[i].oFlags.ContainsKey("ui-comments") && init[j].oFlags.ContainsKey("ui-comments") && !init[i].oFlags["ui-comments"].Equals(string.Empty) && !init[i].oFlags["ui-comments"].Equals("") && !init[j].oFlags["ui-comments"].Equals(string.Empty) && !init[j].oFlags["ui-comments"].Equals(""))
                                        {

                                            if (init[j].oFlags["ui-comments"].Equals(init[i].oFlags["ui-comments"]))
                                            {

                                                if (!ch)
                                                {
                                                    runNum++;


                                                    sb.Append(String.Format("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"{0}\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(init[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);

                                            }
                                        }
                                        else
                                        {
                                            if ((!init[j].oFlags.ContainsKey("ui-comments") || init[j].oFlags["ui-comments"].Equals(string.Empty) || init[j].oFlags["ui-comments"].Equals(""))
                                                && (!init[i].oFlags.ContainsKey("ui-comments") || init[i].oFlags["ui-comments"].Equals(string.Empty) || init[i].oFlags["ui-comments"].Equals("")))
                                            {
                                                if (!ch)
                                                {
                                                    runNum++;
                                                    sb.Append("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"Transaction_Init\" enabled=\"true\">");
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(init[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);
                                            }

                                        }


                                    }




                                }
                                if (ch)
                                {
                                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type2)
                                    {
                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!init[j].oFlags.ContainsKey("ui-comments") || init[j].oFlags["ui-comments"].Equals(string.Empty) || init[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"Aggregate Report\" enabled=\"true\">");
                                            }
                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                            }


                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!init[j].oFlags.ContainsKey("ui-comments") || init[j].oFlags["ui-comments"].Equals(string.Empty) || init[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"View Results in Table\" enabled=\"true\">");

                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                            }

                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results Tree\" enabled=\"true\">", init[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!init[j].oFlags.ContainsKey("ui-comments") || init[j].oFlags["ui-comments"].Equals(string.Empty) || init[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"View Results Tree\" enabled=\"true\">");
                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results Tree\" enabled=\"true\">", init[j].oFlags["ui-comments"]));

                                            }

                                        }

                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");
                                    }
                                    sb.Append("</hashTree>");
                                }
                            }
                        }




                        sb.Append("</hashTree>");

                    }

                    if (action.Count > 0)
                    {

                        if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type3)
                        {
                            sb.Append(String.Format("<ThreadGroup guiclass=\"ThreadGroupGui\" testclass=\"ThreadGroup\" testname=\"BP_010000_{0}\" enabled=\"true\">", this.OfileName));
                        }
                        else
                        {
                            sb.Append(String.Format("<ThreadGroup guiclass=\"ThreadGroupGui\" testclass=\"ThreadGroup\" testname=\"{0}\" enabled=\"true\">", this.OfileName));
                        }
                        sb.Append("<stringProp name=\"ThreadGroup.on_sample_error\">continue</stringProp>");
                        sb.Append("<elementProp name=\"ThreadGroup.main_controller\" elementType=\"LoopController\" guiclass=\"LoopControlPanel\" testclass=\"LoopController\" testname=\"Loop Controller\" enabled=\"true\">");
                        sb.Append("<boolProp name=\"LoopController.continue_forever\">false</boolProp>");
                        sb.Append("<stringProp name=\"LoopController.loops\">1</stringProp>");
                        sb.Append("</elementProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.num_threads\">1</stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.ramp_time\">1</stringProp>");

                        sb.Append("<boolProp name=\"ThreadGroup.scheduler\">false</boolProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.duration\"></stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.delay\"></stringProp>");
                        sb.Append("</ThreadGroup>");
                        // [6]
                        sb.Append("<hashTree>");

                        int runNum = 0, subrun = 0;
                        string nameBefore = string.Empty, nameAfter = string.Empty;
                        bool[] chList = new bool[action.Count];

                        for (int h = 0; h < action.Count; h++)
                        {
                            chList[h] = false;
                        }

                        for (int j = 0; j < action.Count; j++)
                        {
                            subrun = 0;
                            ch = false;
                            if (!chList[j])
                            {
                                for (int i = j; i < action.Count; i++)
                                {
                                    if (!chList[i])
                                    {
                                        if (action[i].oFlags.ContainsKey("ui-comments") && action[j].oFlags.ContainsKey("ui-comments") && !action[i].oFlags["ui-comments"].Equals(string.Empty) && !action[i].oFlags["ui-comments"].Equals("") && !action[j].oFlags["ui-comments"].Equals(string.Empty) && !action[j].oFlags["ui-comments"].Equals(""))
                                        {

                                            if (action[j].oFlags["ui-comments"].Equals(action[i].oFlags["ui-comments"]))
                                            {

                                                if (!ch)
                                                {
                                                    runNum++;

                                                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type3)
                                                    {
                                                        sb.Append(String.Format("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"UA_01{0}00_{1}\" enabled=\"true\">", runNum.ToString("00"), action[j].oFlags["ui-comments"]));
                                                    }
                                                    else
                                                    {
                                                        sb.Append(String.Format("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"{0}\" enabled=\"true\">", action[j].oFlags["ui-comments"]));
                                                    }
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(action[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);

                                            }
                                        }
                                        else
                                        {
                                            if ((!action[j].oFlags.ContainsKey("ui-comments") || action[j].oFlags["ui-comments"].Equals(string.Empty) || action[j].oFlags["ui-comments"].Equals(""))
                                                && (!action[i].oFlags.ContainsKey("ui-comments") || action[i].oFlags["ui-comments"].Equals(string.Empty) || action[i].oFlags["ui-comments"].Equals("")))
                                            {
                                                if (!ch)
                                                {
                                                    runNum++;
                                                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type3)
                                                    {
                                                        sb.Append(String.Format("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"UA_01{0}00\" enabled=\"true\">", runNum.ToString("00")));
                                                    }
                                                    else
                                                    {
                                                        sb.Append("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"Transaction\" enabled=\"true\">");
                                                    }
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(action[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);
                                            }

                                        }


                                    }




                                }
                                if (ch)
                                {
                                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type2)
                                    {
                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"UA_01{0}00_{1}_Aggregate Report\" enabled=\"true\">", runNum.ToString("00"), action[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!action[j].oFlags.ContainsKey("ui-comments") || action[j].oFlags["ui-comments"].Equals(string.Empty) || action[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"Aggregate Report\" enabled=\"true\">");
                                            }
                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", action[j].oFlags["ui-comments"]));
                                            }


                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"UA_01{0}00_{1}_View Results in Table\" enabled=\"true\">", runNum.ToString("00"), action[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!action[j].oFlags.ContainsKey("ui-comments") || action[j].oFlags["ui-comments"].Equals(string.Empty) || action[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"View Results in Table\" enabled=\"true\">");

                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", action[j].oFlags["ui-comments"]));
                                            }

                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"UA_01{0}00_{1}_View Results Tree\" enabled=\"true\">", runNum.ToString("00"), action[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!action[j].oFlags.ContainsKey("ui-comments") || action[j].oFlags["ui-comments"].Equals(string.Empty) || action[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"View Results Tree\" enabled=\"true\">");
                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results Tree\" enabled=\"true\">", action[j].oFlags["ui-comments"]));

                                            }

                                        }

                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");
                                    }
                                    sb.Append("</hashTree>");
                                }
                            }
                        }




                        sb.Append("</hashTree>");

                        
                    }

                    if (end.Count > 0)
                    {
                        sb.Append("<PostThreadGroup guiclass=\"PostThreadGroupGui\" testclass=\"PostThreadGroup\" testname=\"End_ThreadGroup\" enabled=\"true\">");
                        sb.Append("<stringProp name=\"ThreadGroup.on_sample_error\">continue</stringProp>");
                        sb.Append("<elementProp name=\"ThreadGroup.main_controller\" elementType=\"LoopController\" guiclass=\"LoopControlPanel\" testclass=\"LoopController\" testname=\"Loop Controller\" enabled=\"true\">");
                        sb.Append("<boolProp name=\"LoopController.continue_forever\">false</boolProp>");
                        sb.Append("<stringProp name=\"LoopController.loops\">1</stringProp>");
                        sb.Append("</elementProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.num_threads\">1</stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.ramp_time\">1</stringProp>");

                        sb.Append("<boolProp name=\"ThreadGroup.scheduler\">false</boolProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.duration\"></stringProp>");
                        sb.Append("<stringProp name=\"ThreadGroup.delay\"></stringProp>");
                        sb.Append("</PostThreadGroup>");

                        sb.Append("<hashTree>");

                        int runNum = 0, subrun = 0;
                        string nameBefore = string.Empty, nameAfter = string.Empty;
                        bool[] chList = new bool[end.Count];

                        for (int h = 0; h < end.Count; h++)
                        {
                            chList[h] = false;
                        }

                        for (int j = 0; j < end.Count; j++)
                        {
                            subrun = 0;
                            ch = false;
                            if (!chList[j])
                            {
                                for (int i = j; i < end.Count; i++)
                                {
                                    if (!chList[i])
                                    {
                                        if (end[i].oFlags.ContainsKey("ui-comments") && end[j].oFlags.ContainsKey("ui-comments") && !end[i].oFlags["ui-comments"].Equals(string.Empty) && !end[i].oFlags["ui-comments"].Equals("") && !end[j].oFlags["ui-comments"].Equals(string.Empty) && !end[j].oFlags["ui-comments"].Equals(""))
                                        {

                                            if (end[j].oFlags["ui-comments"].Equals(end[i].oFlags["ui-comments"]))
                                            {

                                                if (!ch)
                                                {
                                                    runNum++;


                                                    sb.Append(String.Format("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"{0}\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(end[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);

                                            }
                                        }
                                        else
                                        {
                                            if ((!end[j].oFlags.ContainsKey("ui-comments") || end[j].oFlags["ui-comments"].Equals(string.Empty) || end[j].oFlags["ui-comments"].Equals(""))
                                                && (!end[i].oFlags.ContainsKey("ui-comments") || end[i].oFlags["ui-comments"].Equals(string.Empty) || end[i].oFlags["ui-comments"].Equals("")))
                                            {
                                                if (!ch)
                                                {
                                                    runNum++;
                                                    sb.Append("<TransactionController guiclass=\"TransactionControllerGui\" testclass=\"TransactionController\" testname=\"Transaction_End\" enabled=\"true\">");
                                                    sb.Append("<boolProp name=\"TransactionController.includeTimers\">false</boolProp>");
                                                    sb.Append("<boolProp name=\"TransactionController.parent\">false</boolProp>");
                                                    sb.Append("</TransactionController>");

                                                    sb.Append("<hashTree>");
                                                    ch = true;
                                                }
                                                chList[i] = true;
                                                subrun++;
                                                HTTPSamplerProxy httpSamplerProxy = new HTTPSamplerProxy(end[i], String.Format("01{0}{1}", runNum.ToString("00"), subrun.ToString("00")), this.Type);
                                                sb.Append(httpSamplerProxy.Xml);
                                            }

                                        }


                                    }




                                }
                                if (ch)
                                {
                                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type2)
                                    {
                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!end[j].oFlags.ContainsKey("ui-comments") || end[j].oFlags["ui-comments"].Equals(string.Empty) || end[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"Aggregate Report\" enabled=\"true\">");
                                            }
                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                            }


                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!end[j].oFlags.ContainsKey("ui-comments") || end[j].oFlags["ui-comments"].Equals(string.Empty) || end[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"View Results in Table\" enabled=\"true\">");

                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                            }

                                        }
                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");



                                        if (this.Type == ProfferType.Type1)
                                        {
                                            sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results Tree\" enabled=\"true\">", end[j].oFlags["ui-comments"]));
                                        }
                                        else
                                        {
                                            if (!end[j].oFlags.ContainsKey("ui-comments") || end[j].oFlags["ui-comments"].Equals(string.Empty) || end[j].oFlags["ui-comments"].Equals(""))
                                            {
                                                sb.Append("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"View Results Tree\" enabled=\"true\">");
                                            }

                                            else
                                            {
                                                sb.Append(String.Format("<ResultCollector guiclass=\"ViewResultsFullVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results Tree\" enabled=\"true\">", end[j].oFlags["ui-comments"]));

                                            }

                                        }

                                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                                        sb.Append("<objProp>");
                                        sb.Append("<name>saveConfig</name>");
                                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                                        sb.Append("<time>true</time>");
                                        sb.Append("<latency>true</latency>");
                                        sb.Append("<timestamp>true</timestamp>");
                                        sb.Append("<success>true</success>");
                                        sb.Append("<label>true</label>");
                                        sb.Append("<code>true</code>");
                                        sb.Append("<message>true</message>");
                                        sb.Append("<threadName>true</threadName>");
                                        sb.Append("<dataType>true</dataType>");
                                        sb.Append("<encoding>false</encoding>");
                                        sb.Append("<assertions>true</assertions>");
                                        sb.Append("<subresults>true</subresults>");
                                        sb.Append("<responseData>false</responseData>");
                                        sb.Append("<samplerData>false</samplerData>");
                                        sb.Append("<xml>false</xml>");
                                        sb.Append("<fieldNames>true</fieldNames>");
                                        sb.Append("<responseHeaders>false</responseHeaders>");
                                        sb.Append("<requestHeaders>false</requestHeaders>");
                                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                                        sb.Append("<bytes>true</bytes>");
                                        sb.Append("<sentBytes>true</sentBytes>");
                                        sb.Append("<threadCounts>true</threadCounts>");
                                        sb.Append("<idleTime>true</idleTime>");
                                        sb.Append("<connectTime>true</connectTime>");
                                        sb.Append("</value>");
                                        sb.Append("</objProp>");
                                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                                        sb.Append("</ResultCollector>");
                                        sb.Append("<hashTree/>");
                                    }
                                    sb.Append("</hashTree>");
                                }
                            }
                        }




                        sb.Append("</hashTree>");

                    }


                    if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type2)
                    {
                        if (this.Type == ProfferType.Type1)
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"BP_010000_{0}_Aggregate Report\" enabled=\"true\">", this.OfileName));
                        }
                        else
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"StatVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_Aggregate Report\" enabled=\"true\">", this.OfileName));
                        }
                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                        sb.Append("<objProp>");
                        sb.Append("<name>saveConfig</name>");
                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                        sb.Append("<time>true</time>");
                        sb.Append("<latency>true</latency>");
                        sb.Append("<timestamp>true</timestamp>");
                        sb.Append("<success>true</success>");
                        sb.Append("<label>true</label>");
                        sb.Append("<code>true</code>");
                        sb.Append("<message>true</message>");
                        sb.Append("<threadName>true</threadName>");
                        sb.Append("<dataType>true</dataType>");
                        sb.Append("<encoding>false</encoding>");
                        sb.Append("<assertions>true</assertions>");
                        sb.Append("<subresults>true</subresults>");
                        sb.Append("<responseData>false</responseData>");
                        sb.Append("<samplerData>false</samplerData>");
                        sb.Append("<xml>false</xml>");
                        sb.Append("<fieldNames>true</fieldNames>");
                        sb.Append("<responseHeaders>false</responseHeaders>");
                        sb.Append("<requestHeaders>false</requestHeaders>");
                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                        sb.Append("<bytes>true</bytes>");
                        sb.Append("<sentBytes>true</sentBytes>");
                        sb.Append("<threadCounts>true</threadCounts>");
                        sb.Append("<idleTime>true</idleTime>");
                        sb.Append("<connectTime>true</connectTime>");
                        sb.Append("</value>");
                        sb.Append("</objProp>");
                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                        sb.Append("</ResultCollector>");
                        sb.Append("<hashTree/>");


                        if (this.Type == ProfferType.Type1)
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"SummaryReport\" testclass=\"ResultCollector\" testname=\"BP_010000_{0}_Test_Summary Report\" enabled=\"true\">", this.OfileName));
                        }
                        else
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"SummaryReport\" testclass=\"ResultCollector\" testname=\"{0}_Test_Summary Report\" enabled=\"true\">", this.OfileName));
                        }
                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                        sb.Append("<objProp>");
                        sb.Append("<name>saveConfig</name>");
                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                        sb.Append("<time>true</time>");
                        sb.Append("<latency>true</latency>");
                        sb.Append("<timestamp>true</timestamp>");
                        sb.Append("<success>true</success>");
                        sb.Append("<label>true</label>");
                        sb.Append("<code>true</code>");
                        sb.Append("<message>true</message>");
                        sb.Append("<threadName>true</threadName>");
                        sb.Append("<dataType>true</dataType>");
                        sb.Append("<encoding>false</encoding>");
                        sb.Append("<assertions>true</assertions>");
                        sb.Append("<subresults>true</subresults>");
                        sb.Append("<responseData>false</responseData>");
                        sb.Append("<samplerData>false</samplerData>");
                        sb.Append("<xml>false</xml>");
                        sb.Append("<fieldNames>true</fieldNames>");
                        sb.Append("<responseHeaders>false</responseHeaders>");
                        sb.Append("<requestHeaders>false</requestHeaders>");
                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                        sb.Append("<bytes>true</bytes>");
                        sb.Append("<sentBytes>true</sentBytes>");
                        sb.Append("<threadCounts>true</threadCounts>");
                        sb.Append("<idleTime>true</idleTime>");
                        sb.Append("<connectTime>true</connectTime>");
                        sb.Append("</value>");
                        sb.Append("</objProp>");
                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                        sb.Append("</ResultCollector>");
                        sb.Append("<hashTree/>");


                        if (this.Type == ProfferType.Type1)
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"BP_010000_{0}_View Results in Table\" enabled=\"true\">", this.OfileName));
                        }
                        else
                        {
                            sb.Append(String.Format("<ResultCollector guiclass=\"TableVisualizer\" testclass=\"ResultCollector\" testname=\"{0}_View Results in Table\" enabled=\"true\">", this.OfileName));
                        }
                        sb.Append("<boolProp name=\"ResultCollector.error_logging\">false</boolProp>");
                        sb.Append("<objProp>");
                        sb.Append("<name>saveConfig</name>");
                        sb.Append("<value class=\"SampleSaveConfiguration\">");
                        sb.Append("<time>true</time>");
                        sb.Append("<latency>true</latency>");
                        sb.Append("<timestamp>true</timestamp>");
                        sb.Append("<success>true</success>");
                        sb.Append("<label>true</label>");
                        sb.Append("<code>true</code>");
                        sb.Append("<message>true</message>");
                        sb.Append("<threadName>true</threadName>");
                        sb.Append("<dataType>true</dataType>");
                        sb.Append("<encoding>false</encoding>");
                        sb.Append("<assertions>true</assertions>");
                        sb.Append("<subresults>true</subresults>");
                        sb.Append("<responseData>false</responseData>");
                        sb.Append("<samplerData>false</samplerData>");
                        sb.Append("<xml>false</xml>");
                        sb.Append("<fieldNames>true</fieldNames>");
                        sb.Append("<responseHeaders>false</responseHeaders>");
                        sb.Append("<requestHeaders>false</requestHeaders>");
                        sb.Append("<responseDataOnError>false</responseDataOnError>");
                        sb.Append("<saveAssertionResultsFailureMessage>true</saveAssertionResultsFailureMessage>");
                        sb.Append("<assertionsResultsToSave>0</assertionsResultsToSave>");
                        sb.Append("<bytes>true</bytes>");
                        sb.Append("<sentBytes>true</sentBytes>");
                        sb.Append("<threadCounts>true</threadCounts>");
                        sb.Append("<idleTime>true</idleTime>");
                        sb.Append("<connectTime>true</connectTime>");
                        sb.Append("</value>");
                        sb.Append("</objProp>");
                        sb.Append("<stringProp name=\"filename\"></stringProp>");
                        sb.Append("</ResultCollector>");
                        sb.Append("<hashTree/>");
                    }

                    sb.Append("<ConstantTimer guiclass=\"ConstantTimerGui\" testclass=\"ConstantTimer\" testname=\"Global ThinkTime\" enabled=\"true\">");
                    sb.Append("<stringProp name=\"ConstantTimer.delay\">1000</stringProp>");
                    sb.Append("</ConstantTimer>");
                    sb.Append("<hashTree/>");


                    sb.Append("</hashTree>");
                }

                

                return sb.ToString();
            }
        }
    }

    /// <summary>
    /// This class represents a HTTP Sampler node
    /// </summary>
    public class HTTPSamplerProxy
    {
        Fiddler.Session session;

        private string subRunNumber;

        private ProfferType Type;

        public HTTPSamplerProxy(Fiddler.Session session, string SubRunNumber, ProfferType type)
        {
            this.session = session;
            this.subRunNumber = SubRunNumber;
            this.Type = type;
        }

        // [7] Return the HTTP Request node
        public string Xml
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                if (this.Type == ProfferType.Type1 || this.Type == ProfferType.Type3)
                {
                    sb.Append(String.Format("<HTTPSamplerProxy guiclass=\"HttpTestSampleGui\" "
                              + "testclass=\"HTTPSamplerProxy\" testname=\"TR_{0}_{1}\" enabled=\"true\">"
                              , subRunNumber, Path));
                }
                else
                {
                    sb.Append(String.Format("<HTTPSamplerProxy guiclass=\"HttpTestSampleGui\" "
                              + "testclass=\"HTTPSamplerProxy\" testname=\"{0}\" enabled=\"true\">"
                              , Path));
                }
                sb.Append("<boolProp name=\"HTTPSampler.postBodyRaw\">true</boolProp>");
                sb.Append("<elementProp name=\"HTTPsampler.Arguments\" elementType=\"Arguments\">");
                sb.Append("<collectionProp name=\"Arguments.arguments\">");
                sb.Append("<elementProp name=\"\" elementType=\"HTTPArgument\">");
                sb.Append("<boolProp name=\"HTTPArgument.always_encode\">false</boolProp>");

                sb.Append(String.Format("<stringProp name=\"Argument.value\">{0}</stringProp>", RequestBody));
                sb.Append("<stringProp name=\"Argument.metadata\">=</stringProp>");
                sb.Append("</elementProp>");
                sb.Append("</collectionProp>");
                sb.Append("</elementProp>");

                string[] split = session.host.Split(':');

                sb.Append(String.Format("<stringProp name=\"HTTPSampler.domain\">{0}</stringProp>", split[0]));
                sb.Append(String.Format("<stringProp name=\"HTTPSampler.port\">{0}</stringProp>", Port));
                sb.Append("<stringProp name=\"HTTPSampler.connect_timeout\"></stringProp>");
                sb.Append("<stringProp name=\"HTTPSampler.response_timeout\"></stringProp>");
                sb.Append(String.Format("<stringProp name=\"HTTPSampler.protocol\">{0}</stringProp>"
                          , session.oRequest.headers.UriScheme));
                sb.Append("<stringProp name=\"HTTPSampler.contentEncoding\"></stringProp>");
                sb.Append(String.Format("<stringProp name=\"HTTPSampler.path\">{0}</stringProp>", Path));
                sb.Append(String.Format("<stringProp name=\"HTTPSampler.method\">{0}</stringProp>"
                          , session.oRequest.headers.HTTPMethod.ToUpper()));
                sb.Append("<boolProp name=\"HTTPSampler.follow_redirects\">true</boolProp>");
                sb.Append("<boolProp name=\"HTTPSampler.auto_redirects\">false</boolProp>");
                sb.Append("<boolProp name=\"HTTPSampler.use_keepalive\">true</boolProp>");
                sb.Append("<boolProp name=\"HTTPSampler.DO_MULTIPART_POST\">false</boolProp>");
                sb.Append("<boolProp name=\"HTTPSampler.monitor\">false</boolProp>");
                sb.Append("<stringProp name=\"HTTPSampler.embedded_url_re\"></stringProp>");
                sb.Append("</HTTPSamplerProxy>");
                sb.Append("<hashTree/>");
                return sb.ToString();
            }
        }

        private string Path
        {
            get
            {
                return System.Net.WebUtility.HtmlEncode(session.PathAndQuery);
            }
        }

        private string getPort()
        {
            int port = session.port;
            string protocol = session.oRequest.headers.UriScheme; ;
            if (protocol.ToLower() == ("https") && port == 443)
            {
                return "";
            }
            if (protocol.ToLower() == ("http") && port == 80)
            {
                return "";
            }
            return port.ToString();
        }

        private string Port
        {
            get
            {
                return getPort();
            }
        }

        private string RequestBody
        {
            get
            {
                return System.Net.WebUtility.HtmlEncode(session.GetRequestBodyAsString());
            }
        }

    }
}